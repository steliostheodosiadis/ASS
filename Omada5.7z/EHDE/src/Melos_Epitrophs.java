public class Melos_Epitrophs extends Xrhsths {

	private string name;
	private string code;

	public void MelosEpitrophs() {
		// TODO - implement Melos_Epitrophs.MelosEpitrophs
		throw new UnsupportedOperationException();
	}

}