public class Eishghsh {

	private string text;

	public void Eishghsh() {
		// TODO - implement Eishghsh.Eishghsh
		throw new UnsupportedOperationException();
	}

	public string getText() {
		return this.text;
	}

	/**
	 * 
	 * @param text
	 */
	public void setText(string text) {
		this.text = text;
	}

}