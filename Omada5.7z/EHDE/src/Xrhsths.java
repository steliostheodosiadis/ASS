public class Xrhsths {

	private string name;
	private string code;

	public void Xrhsths() {
		// TODO - implement Xrhsths.Xrhsths
		throw new UnsupportedOperationException();
	}

}