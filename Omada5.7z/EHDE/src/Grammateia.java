public class Grammateia extends Xrhsths {

	private string name;
	private string code;

	public void Grammateia() {
		// TODO - implement Grammateia.Grammateia
		throw new UnsupportedOperationException();
	}

}