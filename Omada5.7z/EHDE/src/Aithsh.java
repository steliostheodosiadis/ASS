public class Aithsh {

	private int protocol_number;
	private ArrayList documents;

	public void Aithsh() {
		// TODO - implement Aithsh.Aithsh
		throw new UnsupportedOperationException();
	}

	public ArrayList getDocuments() {
		return this.documents;
	}

	/**
	 * 
	 * @param documents
	 */
	public void setDocuments(ArrayList documents) {
		this.documents = documents;
	}

	public int getProtocol_number() {
		return this.protocol_number;
	}

	/**
	 * 
	 * @param protocol_number
	 */
	public void setProtocol_number(int protocol_number) {
		this.protocol_number = protocol_number;
	}

}