public class Katastash {

	private string link;

	public Katastash() {
		// TODO - implement Katastash.Katastash
		throw new UnsupportedOperationException();
	}

	public string getLink() {
		return this.link;
	}

	/**
	 * 
	 * @param link
	 */
	public void setLink(string link) {
		this.link = link;
	}

}