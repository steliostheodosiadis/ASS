public class Eishghths extends Xrhsths {

	private string name;
	private string code;

	public void Eishghths() {
		// TODO - implement Eishghths.Eishghths
		throw new UnsupportedOperationException();
	}

}