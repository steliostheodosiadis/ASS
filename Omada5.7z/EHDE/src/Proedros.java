public class Proedros extends Xrhsths {

	private string name;
	private string code;

	public void Proedros() {
		// TODO - implement Proedros.Proedros
		throw new UnsupportedOperationException();
	}

}