public class Kathigitis extends Xrhsths {

	private string name;
	private string code;

	public void Kathigitis() {
		// TODO - implement Kathigitis.Kathigitis
		throw new UnsupportedOperationException();
	}

}