public class Axiologhsh {

	private string text;

	public void Axiologhsh() {
		// TODO - implement Axiologhsh.Axiologhsh
		throw new UnsupportedOperationException();
	}

	public string getText() {
		return this.text;
	}

	/**
	 * 
	 * @param text
	 */
	public void setText(string text) {
		this.text = text;
	}

}